<?php
/*
 * Footer HTML file
 */

//variables
$curYear = date('Y');
?>

<div class="footer">
	<hr/>
	<footer>
		<p style ="margin-left: 50px;">&copy; Tackster.com <?php echo $curYear ?></p>
	</footer>
</div>