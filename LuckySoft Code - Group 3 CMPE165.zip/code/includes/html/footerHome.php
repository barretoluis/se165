<?php
/*
 * Footer HTML file
 */

//variables
$curYear = date('Y');
?>

<div class="footer">
	<footer>
		<br/>
		<p>&copy; <?php echo $curYear ?> Tackster, Inc. &middot; <a href="/company/about/">About</a> &middot; <a href="/company/terms_and_privacy/">Terms & Privacy</a></p>
	</footer>
</div>