<?php

/**
 * This file defines the constants for the database.
 *
 * @author Jerry Phul
 */

define('DB_HOST', 'localhost');
define('DB_USER', 'tackster');
define('DB_PASS', '4tackster2use');
define('DB_NAME', 'db_tackster');

?>
