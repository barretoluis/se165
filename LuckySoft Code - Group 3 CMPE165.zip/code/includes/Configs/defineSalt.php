<?php

/**
 * This file defines the constants for the database.
 *
 * @author Jerry Phul
 */

define('SALT_PASS', 'd9N5z!heP^2');

?>
